## Technologies utilis�es  
Les principales d�pendances ajout�es au projet :  
1. **Spring Web** : Permet de d�velopper des applications web (RESTful API et front-end).  
2. **Spring Data JPA** : Facilite l'acc�s et la manipulation des bases de donn�es en utilisant JPA.  
3. **Hibernate** : Impl�mentation de JPA pour g�rer les entit�s et les bases de donn�es.  
4. **H2 Database** : Base de donn�es l�g�re et en m�moire pour le d�veloppement et les tests.  
5. **Spring Boot DevTools** : Outils pour am�liorer l'exp�rience de d�veloppement (rechargement automatique, etc.).  
6. **Thymeleaf** : Moteur de template pour cr�er des pages HTML dynamiques.  

## Reponses aux questions:

**1. Avec quelle partie du code avons-nous param�tr� l'url d'appel /greeting ?**  

   @GetMapping("/greeting")  
   public String greeting(@RequestParam(name="nameGET", required=false, defaultValue="World") String  
   nameGET, Model model) {  
   model.addAttribute("nomTemplate", nameGET);  
   return "greeting";  
   }  

**2. Avec quelle partie du code avons-nous choisi le fichier HTML � afficher ?**  

Le fichier HTML � afficher est choisi par :  
return "greeting";  
Cela correspond au fichier greeting.html situ� dans le dossier templates.  

**3. Comment envoyons-nous le nom � qui nous disons bonjour avec le second lien ?**  

Le nom est envoy� via le param�tre de requ�te nameGET dans l'URL   
Ce param�tre est captur� par @RequestParam   
Ensuite, il est ajout� au mod�le    
Ce mod�le est utilis� dans le fichier greeting.html pour afficher le message avec la variable ${nomTemplate}. 

**Avez- vous remarqu� une diff�rence ?**  
la table ADDRESS est apparue


**Expliquez l'apparition de la nouvelle table en vous aidant de vos cours sur Hibernate, et de la
d�pendance Hibernate de Spring.**  
La classe `Address` est une entit� JPA, mapp�e � une table `address` dans la base de donn�es gr�ce � Hibernate.

**@Entity** indique � Hibernate que cette classe est une entit� � persister.  
**@Id** marque le champ `id` comme cl� primaire.  
**@GeneratedValue** permet de g�n�rer automatiquement l'ID.  
Spring, avec Spring Data JPA et Hibernate, g�re automatiquement la cr�ation de la table `address` lors du d�marrage.  
Une fois la table cr��e, Spring permet de manipuler les entit�s via des repositories, et la page web peut afficher les donn�es de la table via les services.  

**Voyez-vous tout le contenu de data.sql**  
Non je n'ai pas r�ussi � afficher tout le contenu, je n'ai pas trouv� de solution

**A quoi sert l'annotation @Autowired**  
**@Autowired** sert � injecter automatiquement des d�pendances dans les classes g�r�es par Spring  

**Expliquez la m�thode que vous avez utilis� pour ajouter Bootstrap dans le README.**  
Pour ajouter Bootstrap � mon projet, j'ai utilis� une CDN (Content Delivery Network).  
J'ai mis le lien vers le fichier CSS de Bootstrap dans la balise <head> de mes pages HTML pour appliquer les styles.
J'ai �galement ajout� le lien vers le fichier JavaScript de Bootstrap juste avant la fin de la balise <body> pour activer les fonctionnalit�s interactives  

**Faut-il une cl� API pour appeler MeteoConcept ?**  
Oui, on a besoin d'une cl� pour appeler l'API MeteoConcept.  

**Quelle URL appeler ?**  
https://api.meteo-concept.com/api/forecast/daily?lat={latitude}&lon={longitude}&token={e16392e61525ffa8ad06914e1fc2efc0df44e341da46af29dc60bbaf9aa43b64}  

**Quelle m�thode HTTP utiliser ?**  
M�thode HTTP GET  

**Comment passer les param�tres d'appels ?**  
Les param�tres lat, lon  et token sont pass�s par l'URL.  

**O� est l'information dont j'ai besoin dans la r�ponse :**  

**Pour afficher la temp�rature du lieu vis� par les coordonn�es GPS :**  
Dans le champ temperatureMin et temperatureMax dans la r�ponse JSON  

**Pour afficher la pr�vision de m�t�o du lieu vis� par les coordonn�es GPS :**  
Dans le champ description de l'objet de pr�vision correspondant � la date demand�e  
