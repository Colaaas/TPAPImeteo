package colas.org.controller;

import colas.org.service.MeteoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MeteoController {

    @Autowired
    private MeteoService meteoService;

    @PostMapping("/meteo")
    public String handleMeteoForm(String address) {
        System.out.println("Adresse reçue : " + address);
        return "meteo";
    }


    @GetMapping("/meteo")
    public String getMeteo(Model model) {
        double latitude = 43.622022;
        double longitude = 3.850587;

        String meteoData = meteoService.getPrevisionsMeteo(latitude, longitude);

        model.addAttribute("meteo", meteoData);

        return "meteo";
    }
}
