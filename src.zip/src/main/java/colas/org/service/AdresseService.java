package colas.org.service;

import colas.org.model.FeatureCollection;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AdresseService {

    private static final String API_URL = "https://api-adresse.data.gouv.fr/search/?q=Rue%20Aristote,%2072000%20Le%20Mans";

    public FeatureCollection getAdresseData(String query) {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(API_URL, FeatureCollection.class);
    }
}

