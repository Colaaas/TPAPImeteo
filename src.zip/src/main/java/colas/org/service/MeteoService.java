package colas.org.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class MeteoService {

    @Value("${apiKey}")
    private String apiKey;

    private final RestTemplate restTemplate;

    public MeteoService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getPrevisionsMeteo(double latitude, double longitude) {
        String url = String.format("https://api.meteo-concept.com/api/forecast/daily?lat=%f&lon=%f&token=%s", latitude, longitude, apiKey);
        return restTemplate.getForObject(url, String.class);
    }
}